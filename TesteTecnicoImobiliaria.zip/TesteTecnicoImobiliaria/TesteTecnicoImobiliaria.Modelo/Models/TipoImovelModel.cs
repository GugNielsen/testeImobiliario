﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteTecnicoImobiliaria.Modelo.Models
{
    [Table("TIPO_IMOVEL")]
    public class TipoImovelModel
    {
        [Key]
        public int CD_TIPO_IMOVEL { get; set; }
        public string DS_TIPO_IMOVEL { get; set; }
    }
}

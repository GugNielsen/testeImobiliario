﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.Modelo.Interfaces.Regra
{
    public interface IRnTipoImovel
    {
        TipoImovelViewModel SelecionarTipoImovel(int tipo);
    }
}

﻿using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.Modelo.Interfaces.Regra
{
    public interface IRnCliente
    {
        ClienteViewModel SelecionarCliente(int id);
        ClienteViewModel SelecionarClienteEmail(string email);
        ClienteViewModel SelecionarClienteNome(string nome);
        ClienteViewModel SelecionarClienteCnpjCpf(string cnpjCpf);
        void SalvarCliente(ClienteViewModel cliente);
        List<ClienteViewModel> ListarClientes();
        void DesativarCliente(int id);
        void AtivarCliente(int id);
    }
}

﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TesteTecnicoImobiliaria.Modelo.Interfaces.DAL;
using TesteTecnicoImobiliaria.Modelo.Models;

namespace TesteTecnicoImobiliaria.DAL
{
    public class TipoImovelDAL : ITipoImovelDAL
    {
        private readonly IContextDAL contexto;

        public TipoImovelDAL(IContextDAL contexto)
        {
            this.contexto = contexto;
        }

        public TipoImovelModel SelecionarTipoImovel(int tipo)
        {
            TipoImovelModel tipoImovel;
            using (var connection = contexto.CreateConnection())
            {
                var query = "SELECT * FROM TIPO_IMOVEL WHERE CD_TIPO_IMOVEL =@tipo ";
                tipoImovel = connection.QuerySingle<TipoImovelModel>(query, new { tipo });
            }

            return tipoImovel;
        }
    }
}

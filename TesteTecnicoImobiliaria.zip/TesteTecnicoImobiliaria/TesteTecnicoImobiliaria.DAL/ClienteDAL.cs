﻿using Dapper;
using Dapper.Contrib.Extensions;
using TesteTecnicoImobiliaria.Modelo.Interfaces;
using TesteTecnicoImobiliaria.Modelo.Interfaces.DAL;
using TesteTecnicoImobiliaria.Modelo.Models;

namespace TesteTecnicoImobiliaria.DAL
{
    internal class ClienteDAL : IClienteDAL
    {
        private readonly IContextDAL contexto;

        public ClienteDAL(IContextDAL contexto)
        {
            this.contexto = contexto;
        }

        public void AtualizarCliente(ClienteModel cliente)
        {
            using (var connection = contexto.CreateConnection())
            {
                connection.Update<ClienteModel>(cliente);
            }
        }

        public void CadastrarCliente(ClienteModel cliente)
        {
            using (var connection = contexto.CreateConnection())
            {
                connection.Insert<ClienteModel>(cliente);
            }
        }

        public void AtivarCliente(int id)
        {
            using (var connection = contexto.CreateConnection())
            {
                var query = "UPDATE CLIENTE SET FL_ATIVO = 1 WHERE CD_CLIENTE = @id";
                connection.Execute(query, new { id });
            }
        }

        public void DesativarCliente(int id)
        {
            using (var connection = contexto.CreateConnection())
            {
                var query = "UPDATE CLIENTE SET FL_ATIVO = 0 WHERE CD_CLIENTE = @id";
                connection.Execute(query, new { id });
            }
        }

        public List<ClienteModel> ListarClientes()
        {
            List<ClienteModel> clientes = new List<ClienteModel>();
            using (var connection = contexto.CreateConnection())
            {
                clientes = connection.GetAll<ClienteModel>().ToList();
            }

            return clientes;
        }

        public ClienteModel SelecionarCliente(int id)
        {
            ClienteModel cliente;
            using (var connection = contexto.CreateConnection())
            {
                cliente = connection.Get<ClienteModel>(id);
            }

            return cliente;
        }

        public ClienteModel SelecionarClienteEmail(string email)
        {
            ClienteModel cliente;
            using (var connection = contexto.CreateConnection())
            {
                var query = "SELEC CLIENTE WHERE CD_CLIENTE WHERE  DS_EMAIL = @email";
                cliente = connection.QuerySingleOrDefault<ClienteModel>(query, new { email });
            }

            return cliente;
        }

        public ClienteModel SelecionarClienteNome(string nome)
        {
            ClienteModel cliente;
            using (var connection = contexto.CreateConnection())
            {
                var query = "SELEC CLIENTE WHERE CD_CLIENTE WHERE  NM_CLIENTE = @nome";
                cliente = connection.QuerySingleOrDefault<ClienteModel>(query, new { nome });
            }

            return cliente;
        }

        public ClienteModel SelecionarClienteCnpjCpf(string cnpjCpf)
        {
            if (string.IsNullOrEmpty(cnpjCpf))
            {
                return null; 
            }

            ClienteModel cliente;
            using (var connection = contexto.CreateConnection())
            {
                var query = "SELECT * FROM CLIENTE WHERE NR_CNPJ = @CnpjCpf OR NR_CPF = @CnpjCpf";
                cliente = connection.QuerySingleOrDefault<ClienteModel>(query, new { CnpjCpf = cnpjCpf });
            }

            return cliente;
        }
    }
}

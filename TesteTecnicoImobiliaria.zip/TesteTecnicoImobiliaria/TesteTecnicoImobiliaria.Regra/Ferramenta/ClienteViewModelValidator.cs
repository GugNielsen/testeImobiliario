﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.Regra.Ferramenta
{
    public class ClienteViewModelValidator : AbstractValidator<ClienteViewModel>
    {
        public ClienteViewModelValidator()
        {
            RuleFor(cliente => cliente.Nome).NotEmpty().WithMessage("O campo Nome é obrigatório.");
            RuleFor(cliente => cliente.Email).NotEmpty().EmailAddress().WithMessage("Informe um endereço de e-mail válido.");

            RuleFor(cliente => new { cliente.CPF, cliente.CNPJ })
                .Must(pair => !string.IsNullOrEmpty(pair.CPF) || !string.IsNullOrEmpty(pair.CNPJ))
                .WithMessage("Informe pelo menos CPF ou CNPJ.");

            RuleFor(cliente => new { cliente.CPF, cliente.CNPJ })
                .Must(pair => string.IsNullOrEmpty(pair.CPF) || string.IsNullOrEmpty(pair.CNPJ))
                .WithMessage("Informe apenas CPF ou apenas CNPJ, não ambos.");

            RuleFor(cliente => new { cliente.CPF, cliente.CNPJ })
                 .Must(pair => BeValidCNPJCPF(pair.CPF, pair.CNPJ))
                 .WithMessage("Informe um CPF ou CNPJ válido.");
        }

        private bool BeValidCPF(string cpf)
        {
            // Remover caracteres não numéricos
            string cleanedCpf = new string(cpf.Where(char.IsDigit).ToArray());

            // Verificar se o CPF tem 11 dígitos
            if (cleanedCpf.Length != 11)
            {
                return false;
            }

            // Verificar se todos os dígitos são iguais
            if (cleanedCpf.Distinct().Count() == 1)
            {
                return false;
            }

            // Aplicar o algoritmo de validação do CPF
            int[] cpfArray = cleanedCpf.Select(c => int.Parse(c.ToString())).ToArray();
            int sum1 = 0;
            int sum2 = 0;

            for (int i = 0; i < 9; i++)
            {
                sum1 += cpfArray[i] * (10 - i);
                sum2 += cpfArray[i] * (11 - i);
            }

            int digit1 = (sum1 % 11) < 2 ? 0 : 11 - (sum1 % 11);
            int digit2 = (sum2 % 11) < 2 ? 0 : 11 - (sum2 % 11);

            return cpfArray[9] == digit1 && cpfArray[10] == digit2;
        }

        private bool BeValidCNPJ(string cnpj)
        {
            // Remover caracteres não numéricos
            string cleanedCnpj = new string(cnpj.Where(char.IsDigit).ToArray());

            // Verificar se o CNPJ tem 14 dígitos
            if (cleanedCnpj.Length != 14)
            {
                return false;
            }

            // Verificar se todos os dígitos são iguais
            if (cleanedCnpj.Distinct().Count() == 1)
            {
                return false;
            }

            // Aplicar o algoritmo de validação do CNPJ
            int[] cnpjArray = cleanedCnpj.Select(c => int.Parse(c.ToString())).ToArray();
            int[] weights1 = { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] weights2 = { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            int sum1 = 0;
            int sum2 = 0;

            for (int i = 0; i < 12; i++)
            {
                sum1 += cnpjArray[i] * weights1[i];
                sum2 += cnpjArray[i] * weights2[i];
            }

            int digit1 = (sum1 % 11) < 2 ? 0 : 11 - (sum1 % 11);
            int digit2 = (sum2 % 11) < 2 ? 0 : 11 - (sum2 % 11);

            return cnpjArray[12] == digit1 && cnpjArray[13] == digit2;
        }

        private bool BeValidCNPJCPF(string? cpf, string? cnpj)
        {
            bool res = false;

            if (string.IsNullOrEmpty(cpf))
            {
                if (!BeValidCNPJ(cnpj)) return res;
            }

            else
            {
                if (!BeValidCPF(cpf)) return res;
            }
            res = true;
            return res;
        }
    }
}


﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TesteTecnicoImobiliaria.Modelo.Interfaces;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.Regra.Ferramenta
{
    public class ImovelViewModelValidator : AbstractValidator<ImovelViewModel>
    {
        private readonly IImovelDAL IimovelDAL;
        public ImovelViewModelValidator()
        {
            RuleFor(x => x.DataPublicacao)
                .NotEmpty().WithMessage("A data não pode estar vazia.")
                .Must(BeAValidDate).WithMessage("A data fornecida não é válida ou é posterior à data atual.");
        }

   
        //public ImovelViewModelValidator(IImovelDAL iimovelDAL)
        //{
        //    RuleFor(x => x)
        //       .Must(BeActive).WithMessage("Pelo menos um imóvel ativo deve estar associado ao cliente.");
        //}

        private bool BeAValidDate(string dateStr)
        {
            if (DateTime.TryParse(dateStr, out DateTime inputDate))
            {
                
                DateTime currentDate = DateTime.Now;

              
                return inputDate <= currentDate;
            }

            return false;
        }
    }
}
